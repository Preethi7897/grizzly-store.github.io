package org.medex.service;

import org.medex.beans.Patient;

public interface PatientService {
	boolean registerPatient(Patient p);
	
}
