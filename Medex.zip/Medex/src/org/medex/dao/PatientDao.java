package org.medex.dao;

import org.medex.beans.Appointment;
import org.medex.beans.Patient;

public interface PatientDao {
	
	public boolean insertRegistration(Patient p); //register patient
    /*public boolean insertAppointment(Appointment a);
    public Appointment selectAppointment(Appointment a);
    public boolean deleteAppointment(int appid);*/

}
