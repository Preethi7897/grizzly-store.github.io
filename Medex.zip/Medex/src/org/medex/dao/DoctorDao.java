package org.medex.dao;

import org.medex.beans.Doctor;

public interface DoctorDao {
	boolean insertRegistration(Doctor d);

}
