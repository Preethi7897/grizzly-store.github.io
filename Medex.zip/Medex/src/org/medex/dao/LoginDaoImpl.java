package org.medex.dao;

import java.sql.Connection;
import java.sql.ResultSet;

import org.medex.beans.User;
import org.medex.util.DBConstants;
import org.medex.util.DBUtil;

import com.mysql.jdbc.PreparedStatement;

public class LoginDaoImpl implements LoginDao {

	@Override
	public User selectUser(User u) {
		String name="";
		String role="";
		Connection con=null;
        PreparedStatement pst=null;
        ResultSet rs=null;
        User res= new User();

        try {
               con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
               pst=(PreparedStatement) con.prepareStatement("select p.fname,p.lname,u.role from patient p join user u on p.id=u.id where u.id=? and u.pwd=?");
               pst.setString(1, u.getId());
               pst.setString(2, u.getPwd());
              rs= pst.executeQuery();
               if(rs.next())
               {
            	   name=rs.getString(1)+" "+rs.getString(2) ;
            	   role=rs.getString(3);
            	  res.setName(name);
            	  res.setRole(role);
               }
          
               con.close();
        } catch (Exception e) {
               e.printStackTrace();
        }
        return res;

	}

	}


